package top.lrshuai.optimisticlock.common;

/**
 * 常量类
 */
public interface Consts {
    //转出
    public static final int ACCOUNT_OUT=0;
    //转入
    public static final int ACCOUNT_IN=1;
}
