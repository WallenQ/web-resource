# optimistic-lock
SpringBoot mybatis 乐观锁 代码示例

### 乐观锁重试   
#### 详细描述博客地址:[https://rstyro.github.io/blog/2019/03/08/%E4%B9%90%E8%A7%82%E9%94%81%E9%87%8D%E8%AF%95%E6%9C%BA%E5%88%B6%E4%BB%A3%E7%A0%81%E5%AE%9E%E7%8E%B0/](https://rstyro.github.io/blog/2019/03/08/%E4%B9%90%E8%A7%82%E9%94%81%E9%87%8D%E8%AF%95%E6%9C%BA%E5%88%B6%E4%BB%A3%E7%A0%81%E5%AE%9E%E7%8E%B0/)
